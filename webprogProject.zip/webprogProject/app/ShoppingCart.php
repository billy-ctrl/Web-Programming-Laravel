<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShoppingCart extends Model
{
    protected $table = 'shoppingcarts';

    public function toUser(){
        return $this->hasMany(User::class);
    }

    public function product(){
        return $this->belongsTo(Product::class);
    }
}
