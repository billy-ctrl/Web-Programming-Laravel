<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = 'products';

    public function contypeproduct(){
        return $this->hasMany(ProductType::class);
    }

    public function conshoppingcart(){
        return $this->hasMany(ShoppingCart::class);
    }
    
}
