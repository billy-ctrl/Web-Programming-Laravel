<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\User;

// Code below specifies the controller for Authentication, 
// Meaning that every page that requires Auth are controlled here

class AuthController extends Controller
{
    public function login(){
        return view('login');
    }

    public function loginPost(Request $request){

        $cred = $request->only('email','password');

        if(Auth::attempt($cred)){
            return redirect('/home')->with('status','Login Success!');
        }
    }

    public function register(Request $request){
        return view('/register',['auth'=>true]);
    }

    public function registerPost(Request $request){
        $this->validate($request,[
            'name' => 'required|min:6',
            'email' => 'required|email|unique:users',
            'password' => 'required|alphaNum|min:8',
            'confirmation' => 'required|same:password',
            'gender' => 'required',
            'address' => 'required|min:10',
            'dob' => 'required|date|before:today',
        ]);

        $data = new User();
        $data->name = $request->name;
        $data->email = $request->email;
        $data->password = Hash::make($request->password);
        $data->gender = $request->gender;
        $data->address = $request->address;
        $data->role = '2';
        $data->dob = $request->dob;
        $data->save();

        return redirect('/login')->with('status','Register Success! Please Login :)');
    }

    public function logout(){
        Auth::logout();

        return redirect('/home');
    }

    public function editprofile(){
        return view('editprofile');
    }

    public function editprofilePost(Request $request){
        $this->validate($request,[
            'name' => 'required|min:6',
            'gender' => 'required',
            'address' => 'required|min:10',
            'dob' => 'required|date|before:today'
        ]);

        $id = Auth::id();
        
        DB::table('users')->where('id',$id)->update([
            'name' => $request->name,
            'gender' => $request->gender,
            'dob' => $request->dob,
            'address' => $request->address
        ]);

        return redirect('/home')->with('editprofilestatus','Edit Profile Success!');
    }

}
