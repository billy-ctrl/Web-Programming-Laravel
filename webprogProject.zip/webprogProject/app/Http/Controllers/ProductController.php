<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Product;
use App\ProductType;
use App\ShoppingCart;
use App\Transaction;
use App\TransactionDetail;

// Code below specifies the controller for product
// Meaning that every page that manipulates product are being controlled here

class ProductController extends Controller
{
    public function update(Request $request){
        $id = $request->id;
        $products = Product::where('id','like',"$id")
                                ->first();

        return view('/updateproduct',['products'=>$products]);
    }

    public function updatePost(Request $request){
        $this->validate($request,[
            'productName' => 'required|min:5',
            'productStock' => 'required',
            'productPrice' => 'required',
            'productDesc' => 'required',
            'productImage' => 'image|mimes:jpg,png,gif'
        ]);

        $images = $request['productImage'];
        $namaimages = $images->getClientOriginalName();
        
        DB::table('products')->where('id',$request->id)->update([
            'productName' => $request->productName,
            'productImage' => "img/".$namaimages,
            'productDesc' => $request->productDesc,
            'productPrice' => $request->productPrice,
            'productStock' => $request->productStock
        ]);
    
        $images->move('img',$namaimages);

        return redirect('home');
    }

    public function add(){
        $producttypes = ProductType::all();

        return view('/addproduct',['producttypes'=>$producttypes]);
    }

    public function addPost(Request $request){
        $producttypes = ProductType::all();
    
        $this->validate($request,[
            'productName' => 'required|min:5',
            'productStock' => 'required|numeric|min:0|not_in:0',
            'productPrice' => 'required|numeric|min:0|not_in:0',
            'productDesc' => 'required|min:15',
            'productImage' => 'image|mimes:jpg,png,gif'
        ]);

        $images = $request['productImage'];
        $namaimages = $images->getClientOriginalName();
        
        DB::table('products')->insert([
            'producttypes_id' => $request->producttype,
            'productName' => $request->productName,
            'productImage' => "img/".$namaimages,
            'productDesc' => $request->productDesc,
            'productPrice' => $request->productPrice,
            'productStock' => $request->productStock
        ]);

        $images->move('img',$namaimages);
    
        return redirect('/home')->with('addproductstatus','Add Product Success!');
    }

    public function addproducttype(){
        $producttypes = ProductType::all();

        return view('/addproducttype',['producttypes'=>$producttypes]);
    }

    public function addproducttypePost(Request $request){
        $producttypes = ProductType::all();
    
        $this->validate($request,[
            'productTypeName' => 'required|min:4',
            'productTypeImage' => 'required|image|mimes:jpg,png,gif'
        ]);

        $images = $request['productTypeImage'];
        $namaimages = $images->getClientOriginalName();
        
        DB::table('producttypes')->insert([

            'productTypeName' => $request->productTypeName,
            'productTypeImage' => "img/".$namaimages,
        ]);

        $images->move('img',$namaimages);

        return redirect('/home')->with('addproducttypestatus','Add Product Type Success!');
    }

    public function delete(Request $request){
        
        $products = Product::find($request->id)->delete();

        return redirect('home');
    }

    public function deleteproducttype(Request $request){
        $id = $request->id;
        $products = Product::where('producttypes_id','like',"$id")
                                ->delete();

        $producttypes = ProductType::find($id)->delete();

        return redirect('home');
    }

    public function updateproducttype(){
        $producttypes = ProductType::all();
        return view('updateproducttype',['producttypes'=>$producttypes]);
    }

    public function updateproducttypePost(Request $request){

        $this->validate($request,[
            'productTypeName' => 'required|min:4|unique:producttypes',
            'productTypeImage' => 'image|mimes:jpg,png,gif'
        ]);

        $images = $request['productTypeImage'];
        $namaimages = $images->getClientOriginalName();
        
        DB::table('producttypes')->where('id',$request->id)->update([
            'productTypeName' => $request->productTypeName,
            'productTypeImage' => "img/".$namaimages,
        ]);
    
        $images->move('img',$namaimages);

        return redirect('/home')->with('editproducttypestatus','Edit Product Type Success!');
    }

    public function addtocart(Request $request, $id){
        $userid = Auth::user()->id;

        $products = Product::where('id','like',"$id")
                        ->first();

        $userqty = $request->qty;
        
        $check = $products['productStock'];

        $this->validate($request,[
            'qty' => "required|numeric|min:1|max:$check"
        ]);
        
        $price = $products['productPrice'];
        $subtotal = $price * $userqty;

        DB::table('shoppingcarts')->insert([
            'user_id' => $userid,
            'product_id' => $id,
            'qty' => $userqty,
            'subtotal' => $subtotal
        ]);
        
        return redirect('/home');
    }

    public function addcart(){
        
        $userid = Auth::user()->id;
        $cart = ShoppingCart::where('user_id','like',"$userid")->get();

        $grandtotal = 0;

        foreach($cart as $temp){
            $grandtotal += $temp->subtotal;
        }
        
        return view('/cart',['cart'=>$cart],['grandtotal'=>$grandtotal]);
    }

    public function updateqty(Request $request, $id){
        $userid = Auth::user()->id;

        $products = Product::where('id','like',"$id")
                        ->first();
        
        $newqty = $request->qty;
        $stock = $products['productStock'];

        $this->validate($request,[
            'qty' => "required|numeric|min:1|max:$stock"
        ]);

        $newsubtotal = $products['productPrice'] * $newqty;

        DB::table('shoppingcarts')->where(['user_id' => $userid, 'product_id' => $id])->update([
            'qty' => $newqty,
            'subtotal' => $newsubtotal
        ]);

        return redirect()->action([ProductController::class,'addcart']);
    }

    public function transaction(){
        $userid = Auth::user()->id;

        $carts = ShoppingCart::where('user_id','like',"$userid")->get();

        $grandtotal = 0;

        foreach($carts as $temp){
            $grandtotal += $temp->subtotal;
        }

        $transactions = new Transaction();
        $transactions->user_id = $userid;
        $transactions->grandtotal = $grandtotal;
        $transactions->save();

        $transactions = Transaction::where('user_id','like',"$userid")
                                        ->orderBy('id','desc')
                                        ->first();

        foreach($carts as $cart){
            DB::table('transactiondetails')->insert([
                ['transaction_id' => $transactions->id, 'product_id' => $cart->product_id, 'qty' => $cart->qty, 'subtotal'=>$cart->subtotal]
            ]);

            $minus = ($cart->product->productStock) - ($cart->qty);
            
            DB::table('products')->where(['id'=>$cart->product_id])->update([
                'productStock' => $minus
            ]);

            DB::table('shoppingcarts')->where(['user_id'=>$userid, 'product_id'=>$cart->product_id])
                                            ->delete();
        }
        return redirect('home');
    }

    public function history(){
        $userid = Auth::user()->id;

        $transactions = Transaction::where('user_id','like',"$userid")
                                    ->orderBy('created_at','desc')
                                    ->get();
                                    
        return view('/history',['transactions' => $transactions]);
    }
}
