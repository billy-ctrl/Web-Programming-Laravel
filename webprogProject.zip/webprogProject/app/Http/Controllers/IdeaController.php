<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\ProductType;
use App\Product;
use App\User;

// Code below specifies the main controller of the website
// Consists of home page, product page, and product type page

class IdeaController extends Controller
{
    public function home(){
        $auth = Auth::check();
        $producttypes = ProductType::all();
        return view('home', ['auth' => $auth],['producttypes'=> $producttypes]);
    }

    public function product(Request $request){
        $auth = Auth::check();
        $id = $request->id;

        $products = Product::where('id','like',"$id")
                                ->first();
        return view('product',['auth' => $auth],['products'=> $products]);
    }

    public function producttype(Request $request){
        $auth = Auth::check();
        $id = $request->id;
        
        $products = Product::where([['producttypes_id','like',"$id"],['productName','like',"%".$request->search."%"]])
                                ->paginate(10);
        
        return view('producttype',['auth' => $auth],['products'=> $products]);
    }
}
