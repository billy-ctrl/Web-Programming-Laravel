<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    protected $table = 'transactions';

    public function intoproduct(){
        return $this->belongsTo(Product::class);
    }

    public function transactiondetails(){
        return $this->belongsTo(TransactionDetail::class);
    }
}
