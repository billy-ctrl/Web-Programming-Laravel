<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// This code below specifies the routing of the IDEA Furniture Website
// Home page of the website can be reached through /home

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home','IdeaController@home');

Route::get('/product/{id}', 'IdeaController@product');
Route::get('/producttype/{id}','IdeaController@producttype');

Route::get('/login', 'AuthController@login');
Route::post('/login', 'AuthController@loginPost');

Route::get('/register', 'AuthController@register');
Route::post('/register', 'AuthController@registerPost');

Route::get('/editprofile', 'AuthController@editprofile');
Route::post('/editprofile', 'AuthController@editprofilePost');

Route::get('/logout', 'AuthController@logout');

Route::get('/updateproduct/{id}', 'ProductController@update');
Route::post('/updateproduct/{id}', 'ProductController@updatePost');

Route::get('/addproduct', 'ProductController@add');
Route::post('/addproduct', 'ProductController@addPost');

Route::get('/addproducttype', 'ProductController@addproducttype');
Route::post('/addproducttype', 'ProductController@addproducttypePost');

Route::get('/updateproducttype/{id}', 'ProductController@updateproducttype');
Route::post('/updateproducttype/{id}', 'ProductController@updateproducttypePost');

Route::post('/delete', 'ProductController@delete');
Route::post('/deleteproducttype', 'ProductController@deleteproducttype');

Route::get('/cart', 'ProductController@addcart');
Route::post('/cart/{id}', 'ProductController@addtocart');
Route::post('/shopcart/{id}','ProductController@updateqty');

Route::get('/transaction','ProductController@transaction');

Route::get('/history', 'ProductController@history');