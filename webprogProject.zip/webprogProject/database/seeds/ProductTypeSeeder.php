<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('producttypes')->insert([
            [
                'productTypeName' => 'Bed Frame',
                'productTypeImage' => 'img\bedframe.jpg'
            ],
            [
                'productTypeName' => 'Bookshelf',
                'productTypeImage' => 'img\bookshelf.jpg'
            ],
            [
                'productTypeName' => 'Chair',
                'productTypeImage' => 'img\chair.jpg'
            ],
            [
                'productTypeName' => 'Chest of drawers',
                'productTypeImage' => 'img\chest.jpg'
            ],
            [
                'productTypeName' => 'Dining set',
                'productTypeImage' => 'img\dining.jpg'
            ],
            [
                'productTypeName' => 'Food storage',
                'productTypeImage' => 'img\Food_storage.jpg'
            ],
            [
                'productTypeName' => 'Office Chair',
                'productTypeImage' => 'img\officechair.jpg'
            ],
            [
                'productTypeName' => 'Sofa',
                'productTypeImage' => 'img\SOFA.jpg'
            ],
        ]);
    }
}
