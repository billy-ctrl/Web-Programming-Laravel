<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            
            [
                'name' => 'admin',
                'email' => 'admin@idea.com',
                'password' => bcrypt('admin123'),
                'address' => 'asdf 123',
                'gender' => 'male',
                'role' => '1',
                'dob' => Carbon::parse('2000-01-01')
            ],
            [
                'name' => 'billy',
                'email' => 'billy@gmail.com',
                'password' => bcrypt('billy123'),
                'address' => 'asdf 123',
                'gender' => 'male',
                'role' => '2',
                'dob' => Carbon::parse('2000-01-01')
            ],

        ]);
    }
}
