@extends('master')
@section('content')
<body>
  <div class="container" style="max-width: 1000px; text-align: center; ">
    <div class="card text-center">
        <div class="card-header">
            Shopping Cart
        </div>
    <div class="card mb-8" style="max-width: 1000px; text-align: center; ">
      @foreach($cart as $temp)
        <div class="row ">

          <div class="col-md-6">
            <img src="{{URL::asset($temp->product->productImage)}}" class="card-img" alt="...">
          </div>

          <div class="col-md-6">
            <div class="card-body">
              <h5 class="card-title"> {{$temp->product->productName}}</h5>
              <h5>Rp. {{$temp->product->productPrice}}</h5>
              <form method="POST" action="{{url('shopcart/'.$temp->product_id)}}">
                {{csrf_field()}}
                <h5>Qty:</h5>
                <input type="text" value="{{$temp->qty}}" name="qty">
                <button type="submit">Submit</button>
              </form>

            </div>

            <div class="card-footer-white">
              <h5>
                Subtotal: Rp. {{$temp->subtotal}}
              </h5>
            </div>

          </div>
        </div>
      @endforeach
      <div class="card-footer">
        <h5>Grandtotal: Rp. {{$grandtotal}}</h5>
      </div>
      <div class="col">
        <a href="{{url('transaction')}}" class="btn">Checkout</a>
      </div>
    </div>


</body>
</html>
@endsection