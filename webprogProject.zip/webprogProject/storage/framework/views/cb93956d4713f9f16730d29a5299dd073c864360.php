

<?php $__env->startSection('content'); ?>
    <h1>REGISTER PAGE</h1>

    <form action="" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="alamat">Password:</label>
                    <input type="password" class="form-control" id="password" name="password">
                </div>
                <div class="form-group">
                    <label for="alamat">Password Confirmation:</label>
                    <input type="password" class="form-control" id="confirmation" name="confirmation">
                </div>
                <div class="form-group">
                    <label for="alamat">Name:</label>
                    <input type="text"  class="form-control" id="name" name="name">
                </div>
                <div class="form-group">
                    <label for="alamat">Address:</label>
                    <input type="text"  class="form-control" id="address" name="address">
                </div>
                <div class="form-group">
                    <label for="alamat">Gender:</label>
                    <input type="text"  class="form-control" id="gender" name="gender">
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-md btn-primary">Submit</button>
                    <button type="reset" class="btn btn-md btn-danger">Cancel</button>
                </div>
            </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BINUS\Web Programming\webprogProject\resources\views//register.blade.php ENDPATH**/ ?>