<!doctype html>
<html lang="en">
<head>
  <title>Welcome to IDEA!</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">IDEA</a>
      </div>

      <?php if(Illuminate\Support\Facades\Auth::check() && Illuminate\Support\Facades\Auth::user()->role == '1'): ?>
        <ul class="nav navbar-nav">
          <li class="nav-item">
            <a class="btn dropdown-toggle" style="float:right;background-color:blue; text-align:center; color:gold; font-size:25px; font-weight:bold" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->name); ?></a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="<?php echo e(url('/addproduct')); ?>" style="background-color:blue; color:gold; font-size:25px; font-weight:bold">Add Product</a>
              <div class="dropdown-divider"></div>
              <a href="<?php echo e(url('/addproducttype')); ?>" style="background-color:blue; color:gold; font-size:25px; font-weight:bold" class="dropdown-item">Add Product Type</a>
              <div class="dropdown-divider"></div>
              <a href="<?php echo e(url('/logout')); ?>" style="background-color:blue; color:gold; font-size:25px; font-weight:bold" class="dropdown-item">Logout</a>
            </div>
          </li>
        </ul>

      <?php elseif(Illuminate\Support\Facades\Auth::check() && Illuminate\Support\Facades\Auth::user()->role == '2'): ?>      
        <ul class="nav navbar-nav navbar-right">
          <li class="nav-item">
            <a class="btn dropdown-toggle" style="float:right;background-color:blue; text-align:center; color:gold; font-size:25px; font-weight:bold" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->name); ?></a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="<?php echo e(url('/editprofile')); ?>" style="background-color:blue; color:gold; font-size:25px; font-weight:bold">Edit Profile</a>
              <div class="dropdown-divider"></div>
              <a href="<?php echo e(url('/cart')); ?>" style="background-color:blue; color:gold; font-size:25px; font-weight:bold" class="dropdown-item">Shopping Cart</a>
              <div class="dropdown-divider"></div>
              <a href="<?php echo e(url('/history')); ?>" style="background-color:blue; color:gold; font-size:25px; font-weight:bold" class="dropdown-item">Transaction History</a>
              <div class="dropdown-divider"></div>
              <a href="<?php echo e(url('/logout')); ?>" style="background-color:blue; color:gold; font-size:25px; font-weight:bold" class="dropdown-item">Logout</a>
            </div>
          </li>  
        </ul>
      <?php else: ?>
        <ul class="nav navbar-nav navbar-right">
          <li>
            <a class="nav-link active" aria-current="page" href="<?php echo e(url('/register')); ?>">
                Register
            </a>
          </li>
          <li>
            <a class="nav-link active" aria-current="page" href="<?php echo e(url('/login')); ?>">
              Login
            </a>
          </li>
        </ul>
    <?php endif; ?>
    </div>
  </nav>
  <?php echo $__env->yieldContent('content'); ?>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script> -->

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->

    <link type="text/css" href="css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
    <script type="text/javascript" src="js/jquery-x.x.x.custom.min.js"></script>

    <link type="text/css" href="css/bootstrap.css" rel="stylesheet" />
    <script type="text/javascript" src="js/bootstrap.js"></script>
</body>
<footer>
</footer>
</html><?php /**PATH C:\Users\Billy\Downloads\webprogProject revisi 10\webprogProject\resources\views/master.blade.php ENDPATH**/ ?>