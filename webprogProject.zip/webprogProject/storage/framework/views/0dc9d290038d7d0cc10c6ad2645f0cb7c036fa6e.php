

<?php $__env->startSection('content'); ?>
    <h1>PRODUCT TYPE PAGE</h1>
    
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($temp -> productName); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Billy\Desktop\webprogProject\resources\views/producttype.blade.php ENDPATH**/ ?>