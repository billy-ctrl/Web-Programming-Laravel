
<?php $__env->startSection('content'); ?>
<body>
  <h1>SHOPPING CART PAGE!</h1>
    <div class="card mb-8" style="max-width: 540px; text-align: center; ">
      <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row ">

          <div class="col-md-6">
            <img src="<?php echo e(URL::asset($temp->product->productImage)); ?>" class="card-img" alt="...">
          </div>

          <div class="col-md-6">
            <div class="card-body">
              <h5 class="card-title"> <?php echo e($temp->product->productName); ?></h5>
              <h5>Rp. <?php echo e($temp->product->productPrice); ?></h5>
              <h5>Qty: <?php echo e($temp->qty); ?></h5>
            </div>

            <div class="card-footer">
              <h5>
                Subtotal: Rp. <?php echo e($temp->subtotal); ?>

              </h5>
            </div>

          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="card-footer">
        <h5>Grandtotal: </h5>
      </div>
    </div>

  </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Billy\Downloads\webprogProject revisi 7\webprogProject\resources\views//cart.blade.php ENDPATH**/ ?>