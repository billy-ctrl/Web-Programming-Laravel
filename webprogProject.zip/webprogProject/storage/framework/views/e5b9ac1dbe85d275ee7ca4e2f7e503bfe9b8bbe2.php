

<?php $__env->startSection('content'); ?>
    <h1>SALAH</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Richard\Desktop\Semester 5\Web (lab)\Project\webprogProject\resources\views//salah.blade.php ENDPATH**/ ?>