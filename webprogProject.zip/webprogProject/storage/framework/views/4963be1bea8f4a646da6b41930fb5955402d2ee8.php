
<?php $__env->startSection('content'); ?>
<body>
  <div class="container" style="max-width: 1000px; text-align: center; ">
    <div class="card text-center">
        <div class="card-header">
            Shopping Cart
        </div>
    <div class="card mb-8" style="max-width: 1000px; text-align: center; ">
      <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row ">

          <div class="col-md-6">
            <img src="<?php echo e(URL::asset($temp->product->productImage)); ?>" class="card-img" alt="...">
          </div>

          <div class="col-md-6">
            <div class="card-body">
              <h5 class="card-title"> <?php echo e($temp->product->productName); ?></h5>
              <h5>Rp. <?php echo e($temp->product->productPrice); ?></h5>
              <form method="POST" action="<?php echo e(url('shopcart/'.$temp->product_id)); ?>">
                <?php echo e(csrf_field()); ?>

                <h5>Qty:</h5>
                <input type="text" value="<?php echo e($temp->qty); ?>" name="qty">
                <button type="submit">Submit</button>
              </form>

            </div>

            <div class="card-footer-white">
              <h5>
                Subtotal: Rp. <?php echo e($temp->subtotal); ?>

              </h5>
            </div>

          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="card-footer">
        <h5>Grandtotal: Rp. <?php echo e($grandtotal); ?></h5>
      </div>
      <div class="col">
        <a href="<?php echo e(url('transaction')); ?>" class="btn">Checkout</a>
      </div>
    </div>


</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Billy\Downloads\webprogProject revisi 9\webprogProject\resources\views//cart.blade.php ENDPATH**/ ?>