

<?php $__env->startSection('content'); ?>
    <h1>This Is Home Page</h1>

    <?php if($auth): ?>
    <h2>logged in as <?php echo e(Auth::user()->name); ?></h2>
    <?php endif; ?>
    <h2>wkwkwk</h2>
    <?php $__currentLoopData = $producttype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1><?php echo e($img->name); ?></h1>
        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Richard\Desktop\Semester 5\Web (lab)\Project\webprogProject\resources\views//home.blade.php ENDPATH**/ ?>