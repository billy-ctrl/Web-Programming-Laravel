

<?php $__env->startSection('content'); ?>
    <h1 style="text-align: center;">Product Type</h1>

    <?php if($auth): ?>
    <h2>logged in as <?php echo e(Auth::user()->name); ?></h2>
    <?php endif; ?>
    <div class="row">
        
        <?php $__currentLoopData = $producttypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-2">
            <div class="card">
            <div class="card-body">
            <img src="<?php echo e(URL::asset($pt->productTypeImage)); ?>" class="card-img-top " style="  height: 300px; margin:auto;"> 
                <a href="/producttype/<?php echo e($pt->id); ?>" class="btn btn-primary"><?php echo e($pt->productTypeName); ?></a>
            </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>


         

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Richard\Desktop\Semester 5\Web (lab)\Project\webprogProject\resources\views/home.blade.php ENDPATH**/ ?>