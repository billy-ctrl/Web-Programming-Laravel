

<?php $__env->startSection('content'); ?>
    <h1>PRODUCT PAGE</h1>

    <?php if($auth): ?>
        <h2>logged in as <?php echo e(Auth::user()->name); ?></h2>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Richard\Desktop\Semester 5\Web (lab)\Project\webprogProject\resources\views/product.blade.php ENDPATH**/ ?>