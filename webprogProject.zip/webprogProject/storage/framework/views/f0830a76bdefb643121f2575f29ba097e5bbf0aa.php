
<?php $__env->startSection('content'); ?>

<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>

<body>
  <?php if(session('status')): ?>
    <div class="alert alert-success">
      <?php echo e(session('status')); ?>

    </div>
  <?php endif; ?>

  <?php if(session('addproductstatus')): ?>
    <div class="alert alert-success">
      <?php echo e(session('addproductstatus')); ?>

    </div>
  <?php endif; ?>

  <?php if(session('addproducttypestatus')): ?>
    <div class="alert alert-success">
      <?php echo e(session('addproducttypestatus')); ?>

    </div>
  <?php endif; ?>

  <?php if(session('editproducttypestatus')): ?>
    <div class="alert alert-success">
      <?php echo e(session('editproducttypestatus')); ?>

    </div>
  <?php endif; ?>

  <?php if(session('editprofilestatus')): ?>
    <div class="alert alert-success">
      <?php echo e(session('editprofilestatus')); ?>

    </div>
  <?php endif; ?>

  <h1 style="text-align: center; background-color:white; color:blue">Home</h1>
    <?php if($auth): ?>
      <div class="row row-cols-1 row-cols-md-3 g-4">   
        <?php $__currentLoopData = $producttypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tempproducttype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col">
            <div class="card h-100">
              <img src="<?php echo e(URL::asset($tempproducttype->productTypeImage)); ?>" class="card-img-top">
                <div class="card-body"> 
                  <div class="text-center">
                    <a class="btn btn-dark btn-lg" href="/producttype/<?php echo e($tempproducttype->id); ?> " style="text-align: center;" role="button"><?php echo e($tempproducttype->productTypeName); ?></a> 
                  </div>
                  <br>
                  <?php if(Auth::user()->role == '1'): ?>
                    <div class="card-footer text-center">
                      <a href="/updateproducttype/<?php echo e($tempproducttype->id); ?>" class="btn btn-warning">Update</a>
                      <br>
                      <br>
                      <form action="/deleteproducttype" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" class="btn btn-primary" name="id" value="<?php echo e($tempproducttype->id); ?>"></input>
                        <input type="submit" class="btn btn-primary" value="Delete"></input>
                      </form>
                    </div>
                  <?php endif; ?>
                </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php else: ?>
      <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php $__currentLoopData = $producttypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tempproducttype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col">
            <div class="card">
              <img src="<?php echo e(URL::asset($tempproducttype->productTypeImage)); ?>" class="card-img-top">
              <div class="card-body"> 
                <div class="text-center">
                  <a class="btn btn-dark btn-lg" href="/producttype/<?php echo e($tempproducttype->id); ?> " style="text-align: center;" role="button"><?php echo e($tempproducttype->productTypeName); ?></a> 
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php endif; ?>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
</body>
</html>
<?php $__env->stopSection(); ?>


         

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Billy\Downloads\webprogProject revisi 7\webprogProject\resources\views/home.blade.php ENDPATH**/ ?>