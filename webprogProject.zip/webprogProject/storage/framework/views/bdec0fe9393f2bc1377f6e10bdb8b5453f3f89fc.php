<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <style>

        a{
            color: black;
            padding: 0 25px;
            font-size: 20px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .header{
            background-color: aqua;
            height: 30px;
            margin: 0px;
            top: 18px;
        }

        .rightHeader{
            position: absolute;
            right: 10px;
        }

    </style>
</head>
<body>
    <div class="header">
        <a href="<?php echo e(url('/home')); ?>">IDEA</a>

        <!-- <a href="<?php echo e(url('/product')); ?>">Products</a> -->
        <!-- <a href="<?php echo e(url('/producttype')); ?>">Product Types</a> -->

        <?php if($auth): ?>
            <a href="<?php echo e(url('/logout')); ?>" class="rightHeader">Logout</a>
        <?php else: ?>
            <a href="<?php echo e(url('/login')); ?>" class="rightHeader">Login</a>
            <br>
            <br>
            <a href="<?php echo e(url('/register')); ?>" class="rightHeader">Register</a>
        <?php endif; ?>
       
        
    </div>

    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\Users\Richard\Desktop\Semester 5\Web (lab)\Project\webprogProject\resources\views/master.blade.php ENDPATH**/ ?>